URL: https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node
---
[Skip to main content](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#main-content)

[![Gemini API](https://ai.google.dev/_static/googledevai/images/lockup-new.svg?hl=es-419)](https://ai.google.dev/)

`/`

- [English](https://ai.google.dev/gemini-api/docs/audio?lang=node)
- [Deutsch](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=de)
- [Español – América Latina](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=es-419)
- [Français](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=fr)
- [Indonesia](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=id)
- [Italiano](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=it)
- [Polski](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=pl)
- [Português – Brasil](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=pt-br)
- [Shqip](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=sq)
- [Tiếng Việt](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=vi)
- [Türkçe](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=tr)
- [Русский](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=ru)
- [עברית](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=he)
- [العربيّة](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=ar)
- [فارسی](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=fa)
- [हिंदी](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=hi)
- [বাংলা](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=bn)
- [ภาษาไทย](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=th)
- [中文 – 简体](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=zh-cn)
- [中文 – 繁體](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=zh-tw)
- [日本語](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=ja)
- [한국어](https://ai.google.dev/gemini-api/docs/audio?lang=node&hl=ko)

[Acceder](https://ai.google.dev/_d/signin?continue=https%3A%2F%2Fai.google.dev%2Fgemini-api%2Fdocs%2Faudio%3Fhl%3Des-419%26lang%3Dnode&prompt=select_account)

- En esta página
- [Formatos de audio compatibles](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#supported-formats)
  - [Detalles técnicos sobre el audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#technical-details)
- [Antes de comenzar: Configura tu proyecto y clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#set-up-project-and-api-key)
  - [Obtén y protege tu clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#get-and-secure-api-key)
  - [Instala el paquete del SDK y configura tu clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#install-package-and-configure-key)
- [Cómo hacer que un archivo de audio esté disponible para Gemini](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#making-audio-available)
- [Sube un archivo de audio y genera contenido](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#upload-audio)
- [Cómo obtener metadatos de un archivo](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#get-metadata)
- [Cómo ver la lista de archivos subidos](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#list-uploaded)
- [Borra archivos subidos](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#delete-uploaded)
- [Proporciona el archivo de audio como datos intercalados en la solicitud](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#inline-data)
- [Más formas de trabajar con audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#more-audio)
  - [Obtén una transcripción del archivo de audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#transcript)
  - [Consulta las marcas de tiempo en el archivo de audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#timestamps)
  - [Cuenta tokens](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#count-tokens)
- [¿Qué sigue?](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#whats-next)


Ya está disponible la versión experimental de Gemini 2.0 Flash. [Más información](https://developers.googleblog.com/en/the-next-chapter-of-the-gemini-era-for-developers/)

![](https://ai.google.dev/_static/images/translated.svg?hl=es-419)

Se usó la [API de Cloud Translation](https://cloud.google.com/translate/?hl=es-419) para traducir esta página.


- [Página principal](https://ai.google.dev/?hl=es-419)
- [Gemini API](https://ai.google.dev/gemini-api?hl=es-419)
- [Modelos](https://ai.google.dev/gemini-api/docs?hl=es-419)

¿Te resultó útil?



 Enviar comentarios



# Explora las capacidades de audio con la API de Gemini

- En esta página
- [Formatos de audio compatibles](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#supported-formats)
  - [Detalles técnicos sobre el audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#technical-details)
- [Antes de comenzar: Configura tu proyecto y clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#set-up-project-and-api-key)
  - [Obtén y protege tu clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#get-and-secure-api-key)
  - [Instala el paquete del SDK y configura tu clave de API](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#install-package-and-configure-key)
- [Cómo hacer que un archivo de audio esté disponible para Gemini](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#making-audio-available)
- [Sube un archivo de audio y genera contenido](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#upload-audio)
- [Cómo obtener metadatos de un archivo](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#get-metadata)
- [Cómo ver la lista de archivos subidos](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#list-uploaded)
- [Borra archivos subidos](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#delete-uploaded)
- [Proporciona el archivo de audio como datos intercalados en la solicitud](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#inline-data)
- [Más formas de trabajar con audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#more-audio)
  - [Obtén una transcripción del archivo de audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#transcript)
  - [Consulta las marcas de tiempo en el archivo de audio](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#timestamps)
  - [Cuenta tokens](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#count-tokens)
- [¿Qué sigue?](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#whats-next)

PythonPython Gen AINode.jsGoREST

Gemini puede responder instrucciones sobre el audio. Por ejemplo, Gemini puede hacer lo siguiente:

- Describir, resumir o responder preguntas sobre el contenido de audio
- Proporciona una transcripción del audio.
- Proporcionar respuestas o una transcripción sobre un segmento específico del audio

En esta guía, se muestran diferentes formas de interactuar con archivos de audio y contenido de audio con la API de Gemini.

## Formatos de audio compatibles

Gemini admite los siguientes tipos de MIME de formato de audio:

- WAV - `audio/wav`
- MP3 - `audio/mp3`
- AIFF: `audio/aiff`
- AAC - `audio/aac`
- OGG Vorbis: `audio/ogg`
- FLAC - `audio/flac`

### Detalles técnicos sobre el audio

Gemini impone las siguientes reglas en el audio:

- Gemini representa cada segundo de audio como 25 tokens. Por ejemplo, un minuto de audio se representa como 1,500 tokens.
- Gemini solo puede inferir respuestas a la voz en inglés.
- Gemini puede “entender” componentes que no son de voz, como cantos de pájaros o sirenas.
- La duración máxima admitida de los datos de audio en una sola instrucción es de 9.5 horas.
Gemini no limita la _cantidad_ de archivos de audio en una sola instrucción. Sin embargo, la duración total combinada de todos los archivos de audio en una sola instrucción no puede exceder las 9.5 horas.
- Gemini reduce la muestra de los archivos de audio a una resolución de datos de 16 Kbps.
- Si la fuente de audio contiene varios canales, Gemini los combina en uno solo.

## Antes de comenzar: Configura tu proyecto y clave de API

Antes de llamar a la API de Gemini, debes configurar tu proyecto y tu clave de API.

**Expande para ver cómo configurar tu proyecto y clave de API**

### Obtén y protege tu clave de API

Necesitas una clave de API para llamar a la API de Gemini. Si aún no tienes una,
crea una clave en Google AI Studio.

[Obtén una clave de API](https://aistudio.google.com/app/apikey?hl=es-419)

Te recomendamos que _no_ registres una clave de API en tu sistema de control de versión.

Debes almacenar tu clave de API en un almacén de secretos, como [Secret Manager](https://cloud.google.com/secret-manager/docs?hl=es-419) de Google Cloud.

En este instructivo, se supone que accedes a tu clave de API como una variable de
entorno.

### Instala el paquete del SDK y configura tu clave de API

En tu app, haz lo siguiente:

1. Instala el paquete `GoogleGenerativeAI` para Node.js:








```
npm install @google/generative-ai

```

2. Importa el paquete y configura el servicio con tu clave de API:








```
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Access your API key as an environment variable
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

```


## Cómo hacer que un archivo de audio esté disponible para Gemini

Puedes hacer que un archivo de audio esté disponible para Gemini de las siguientes maneras:

- [Sube](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#upload-audio) el archivo de audio _antes_ de realizar la solicitud de instrucción.
- Proporciona el archivo de audio como [datos intercalados](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#inline-data) en la solicitud de instrucciones.

## Sube un archivo de audio y genera contenido

Puedes usar la API de File para subir un archivo de audio de cualquier tamaño. Usa siempre la API de File cuando el tamaño total de la solicitud (incluidos los archivos, el mensaje de texto, las instrucciones del sistema, etcétera) sea superior a 20 MB.

Llama a [`media.upload`](https://ai.google.dev/api/rest/v1beta/media/upload?hl=es-419) para subir un archivo con la API de File. El siguiente código sube un archivo de audio y, luego, lo usa en una llamada a [`models.generateContent`](https://ai.google.dev/api/generate-content?hl=es-419#method:-models.generatecontent).

```
// Make sure to include these imports:
// import { GoogleAIFileManager, FileState } from "@google/generative-ai/server";
// import { GoogleGenerativeAI } from "@google/generative-ai";
const fileManager = new GoogleAIFileManager(process.env.API_KEY);

const uploadResult = await fileManager.uploadFile(
  `${mediaPath}/samplesmall.mp3`,
  {
    mimeType: "audio/mp3",
    displayName: "Audio sample",
  },
);

let file = await fileManager.getFile(uploadResult.file.name);
while (file.state === FileState.PROCESSING) {
  process.stdout.write(".");
  // Sleep for 10 seconds
  await new Promise((resolve) => setTimeout(resolve, 10_000));
  // Fetch the file from the API again
  file = await fileManager.getFile(uploadResult.file.name);
}

if (file.state === FileState.FAILED) {
  throw new Error("Audio processing failed.");
}

// View the response.
console.log(
  `Uploaded file ${uploadResult.file.displayName} as: ${uploadResult.file.uri}`,
);

const genAI = new GoogleGenerativeAI(process.env.API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
const result = await model.generateContent([\
  "Tell me about this audio clip.",\
  {\
    fileData: {\
      fileUri: uploadResult.file.uri,\
      mimeType: uploadResult.file.mimeType,\
    },\
  },\
]);
console.log(result.response.text());
files.js

```

## Cómo obtener metadatos de un archivo

Para verificar que la API almacenó correctamente el archivo subido y obtener sus metadatos, llama a [`files.get`](https://ai.google.dev/api/rest/v1beta/files/get?hl=es-419).

```
// Make sure to include these imports:
// import { GoogleAIFileManager } from "@google/generative-ai/server";
const fileManager = new GoogleAIFileManager(process.env.API_KEY);

const uploadResponse = await fileManager.uploadFile(
  `${mediaPath}/jetpack.jpg`,
  {
    mimeType: "image/jpeg",
    displayName: "Jetpack drawing",
  },
);

// Get the previously uploaded file's metadata.
const getResponse = await fileManager.getFile(uploadResponse.file.name);

// View the response.
console.log(
  `Retrieved file ${getResponse.displayName} as ${getResponse.uri}`,
);
files.js

```

## Cómo ver la lista de archivos subidos

Puedes subir varios archivos de audio (y otros tipos de archivos).
El siguiente código genera una lista de todos los archivos subidos:

```
// Make sure to include these imports:
// import { GoogleAIFileManager } from "@google/generative-ai/server";
const fileManager = new GoogleAIFileManager(process.env.API_KEY);

const listFilesResponse = await fileManager.listFiles();

// View the response.
for (const file of listFilesResponse.files) {
  console.log(`name: ${file.name} | display name: ${file.displayName}`);
}
files.js

```

## Borra archivos subidos

Los archivos se borran automáticamente después de 48 horas. De manera opcional, puedes borrar manualmente un archivo subido. Por ejemplo:

```
// Make sure to include these imports:
// import { GoogleAIFileManager } from "@google/generative-ai/server";
const fileManager = new GoogleAIFileManager(process.env.API_KEY);

const uploadResult = await fileManager.uploadFile(
  `${mediaPath}/jetpack.jpg`,
  {
    mimeType: "image/jpeg",
    displayName: "Jetpack drawing",
  },
);

// Delete the file.
await fileManager.deleteFile(uploadResult.file.name);

console.log(`Deleted ${uploadResult.file.displayName}`);
files.js

```

## Proporciona el archivo de audio como datos intercalados en la solicitud

En lugar de subir un archivo de audio, puedes pasar datos de audio en la misma llamada que contiene la instrucción.

Luego, pasa ese pequeño archivo de audio descargado junto con la instrucción a Gemini:

```
const base64Buffer = fs.readFileSync(join(__dirname, "./samplesmall.mp3"));
const base64AudioFile = base64Buffer.toString("base64");

// Initialize a Gemini model appropriate for your use case.
const model = genAI.getGenerativeModel({
  model: "gemini-1.5-flash",
});

// Generate content using a prompt and the metadata of the uploaded file.
const result = await model.generateContent([\
    {\
      inlineData: {\
        mimeType: "audio/mp3",\
        data: base64AudioFile\
      }\
    },\
    { text: "Please summarize the audio." },\
  ]);

// Print the response.
console.log(result.response.text())

```

Ten en cuenta lo siguiente sobre la forma de proporcionar audio como datos intercalados:

- El tamaño máximo de la solicitud es de 20 MB, lo que incluye instrucciones de texto, instrucciones del sistema y archivos proporcionados intercalados. Si el tamaño de tu archivo hará que el _tamaño total de la solicitud_ supere los 20 MB, [usa la API de File](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#upload-audio) para subir archivos para usarlos en las solicitudes.
- Si usas un sample de audio varias veces, es más eficiente [usar la API de File](https://ai.google.dev/gemini-api/docs/audio?hl=es-419&lang=node#upload-audio).

## Más formas de trabajar con audio

En esta sección, se proporcionan algunas formas adicionales de aprovechar al máximo el audio.

### Obtén una transcripción del archivo de audio

Para obtener una transcripción, solo pídela en la instrucción. Por ejemplo:

```
// To generate content, use this import path for GoogleGenerativeAI.
// Note that this is a different import path than what you use for the File API.
import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize GoogleGenerativeAI with your API_KEY.
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

// Initialize a Gemini model appropriate for your use case.
const model = genAI.getGenerativeModel({
  model: "gemini-1.5-flash",
});

// Generate content using a prompt and the metadata of the uploaded file.
const result = await model.generateContent([\
    {\
      fileData: {\
        mimeType: audioFile.file.mimeType,\
        fileUri: audioFile.file.uri\
      }\
    },\
    { text: "Generate a transcript of the speech." },\
  ]);

// Print the response.
console.log(result.response.text())

```

### Consulta las marcas de tiempo en el archivo de audio

Una instrucción puede especificar marcas de tiempo del formato `MM:SS` para hacer referencia a secciones particulares en un archivo de audio. Por ejemplo, la siguiente instrucción solicita una transcripción que cumpla con los siguientes requisitos:

- Comienza a los 2 minutos y 30 segundos desde el principio del archivo.
- Finaliza a los 3 minutos y 29 segundos desde el principio del archivo.

```
// Create a prompt containing timestamps.
const prompt = "Provide a transcript of the speech from 02:30 to 03:29."

```

### Cuenta tokens

Llama al método [`countTokens`](https://ai.google.dev/api/rest/v1/models/countTokens?hl=es-419) para obtener un recuento de la cantidad de tokens en el archivo de audio. Por ejemplo:

```
const countTokensResult = await model.countTokens({
   generateContentRequest: {
     contents: [\
       {\
         role: "user",\
         parts: [\
           {\
             fileData: {\
               mimeType: audioFile.file.mimeType,\
               fileUri: audioFile.file.uri,\
             },\
           },\
         ],\
       },\
     ],
   },
 });

```

## ¿Qué sigue?

En esta guía, se muestra cómo subir archivos de audio con la API de File y, luego, generar resultados de texto a partir de entradas de audio. Para obtener más información, consulta los siguientes recursos:

- [Estrategias de indicaciones de archivos](https://ai.google.dev/gemini-api/docs/file-prompting-strategies?hl=es-419): La API de Gemini admite indicaciones con datos de texto, imagen, audio y video, también conocidos como indicaciones multimodales.
- [Instrucciones del sistema](https://ai.google.dev/gemini-api/docs/system-instructions?hl=es-419): Las instrucciones del sistema te permiten dirigir el comportamiento del modelo según tus necesidades y casos de uso específicos.
- [Orientación de seguridad](https://ai.google.dev/gemini-api/docs/safety-guidance?hl=es-419): A veces, los modelos de IA generativa producen resultados inesperados, como resultados imprecisos, sesgados o ofensivos. El procesamiento posterior y la evaluación humana son esenciales para limitar el riesgo de daños que pueden causar estos resultados.

¿Te resultó útil?



 Enviar comentarios



Salvo que se indique lo contrario, el contenido de esta página está sujeto a la [licencia Atribución 4.0 de Creative Commons](https://creativecommons.org/licenses/by/4.0/), y los ejemplos de código están sujetos a la [licencia Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0). Para obtener más información, consulta las [políticas del sitio de Google Developers](https://developers.google.com/site-policies?hl=es-419). Java es una marca registrada de Oracle o sus afiliados.

Última actualización: 2025-01-16 (UTC)