import type { Express } from "express";
import { createServer, type Server } from "http";
import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from 'dotenv';

dotenv.config();

const DEFAULT_API_KEY = process.env.GEMINI_API_KEY;
if (!DEFAULT_API_KEY) {
  throw new Error("Missing GEMINI_API_KEY environment variable");
}

interface ChatSettings {
  systemInstruction: string;
  temperature: number;
  topP: number;
  topK: number;
  maxOutputTokens: number;
  customApiKey?: string;
}

export function registerRoutes(app: Express): Server {
  app.post("/api/chat", async (req, res) => {
    try {
      const { content, image, settings, history } = req.body;

      // Debug logs
      console.log("Received request with settings:", JSON.stringify(settings, null, 2));
      console.log("History length:", history?.length);

      // Use default settings if none provided
      const finalSettings = settings || {
        systemInstruction: `Hola, te llamas raul y estas para atender a los usuarios`,
        temperature: 0.80,
        topP: 0.92,
        topK: 40,
        maxOutputTokens: 20000,
      };

      const apiKey = finalSettings.customApiKey || DEFAULT_API_KEY;
      if (!apiKey) {
        throw new Error("No valid API key provided");
      }

      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({
        model: "gemini-2.0-flash-exp",
      });

      let response;
      if (image) {
        const visionModel = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
        const imageParts = [
          { text: content },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: image.split(",")[1],
            },
          },
        ];
        response = await visionModel.generateContent(imageParts);
      } else {
        // Create chat with history and configuration
        const chat = model.startChat({
          history: history || [],
          generationConfig: {
            temperature: finalSettings.temperature,
            topP: finalSettings.topP,
            topK: finalSettings.topK,
            maxOutputTokens: finalSettings.maxOutputTokens,
          }
        });

        // Send the current message
        response = await chat.sendMessage(content);
      }

      const result = await response.response;
      res.json({ response: result.text() });
    } catch (error: any) {
      console.error("Error in chat endpoint:", error);
      res.status(500).json({ 
        error: "Internal server error",
        details: error.message 
      });
    }
  });

  return createServer(app);
}